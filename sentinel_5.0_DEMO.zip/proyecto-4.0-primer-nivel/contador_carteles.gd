extends Label

var total := 0
var leidos := 0


func _ready() -> void:
	# Estilo y posición: arriba a la derecha
	add_theme_font_size_override("font_size", 14)
	add_theme_color_override("font_outline_color", Color.BLACK)
	add_theme_constant_override("outline_size", 4)
	set_anchors_and_offsets_preset(Control.PRESET_TOP_RIGHT, Control.PRESET_MODE_MINSIZE, 8)
	grow_horizontal = Control.GROW_DIRECTION_BEGIN

	await get_tree().process_frame      # espera a que existan los carteles
	var carteles := get_tree().get_nodes_in_group("carteles")
	total = carteles.size()
	if total == 0:
		visible = false                 # nivel sin carteles: no se muestra
		return
	for c in carteles:
		c.leido.connect(_on_cartel_leido)
	_actualizar()


func _on_cartel_leido() -> void:
	leidos += 1
	_actualizar()


func _actualizar() -> void:
	if leidos >= total:
		text = "¡Todos los carteles leídos! Busca el portal"
	else:
		text = "Carteles: %d/%d" % [leidos, total]
