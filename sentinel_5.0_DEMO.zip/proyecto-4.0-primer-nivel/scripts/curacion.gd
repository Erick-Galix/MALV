extends Area2D

@export var cantidad := 1
## 0 = un solo uso. Si pones por ejemplo 20, reaparece a los 20 segundos
@export var tiempo_reaparicion := 0.0

var disponible := true


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2        # detecta al jugador (capa 2)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void:
	if not disponible or not body.is_in_group("player"):
		return
	if body.health >= body.max_health:
		return                # vida completa: no se gast
		body.heal(cantidad)
	disponible = false
	visible = false
	if tiempo_reaparicion > 0.0:
		await get_tree().create_timer(tiempo_reaparicion).timeout
		visible = true
		disponible = true
	else:
		queue_free()
