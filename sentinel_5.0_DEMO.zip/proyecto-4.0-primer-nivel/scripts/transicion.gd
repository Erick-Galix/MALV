class_name Transicion
extends CanvasLayer
## Transición entre niveles: pantalla en negro, título y relato del nivel que se
## escribe letra por letra, y luego fundido al nivel nuevo.
##
## NO es un autoload: se crea sola la primera vez que se usa.
## Uso (como ya lo hace tu portal):
##   Transicion.cambiar_nivel("res://scenes/nivel2.tscn", "NIVEL 2", "texto del relato...")

const CHARS_PER_SECOND := 70.0   # velocidad de escritura del relato
const GREEN := Color("33ff66")

static var instance: Transicion

var overlay: ColorRect       # el telón negro
var content: Control         # título + relato + aviso
var title_label: Label
var body_label: Label
var hint_label: Label
var hint_tween: Tween

var busy := false
var reading := false         # ¿se está leyendo el relato? (para captar las teclas)
var typing_done := false
var skip_typing := false
var continue_pressed := false


# ---------------------------------------------------------------- uso desde fuera
static func cambiar_nivel(ruta: String, titulo := "", texto := "") -> void:
	var inst := _get_instance()
	# Siempre diferido: así es seguro llamarlo desde body_entered u otras señales de física
	inst._run.call_deferred(ruta, titulo, texto)


static func esta_ocupada() -> bool:
	return instance != null and is_instance_valid(instance) and instance.busy


static func _get_instance() -> Transicion:
	if instance == null or not is_instance_valid(instance):
		var tree := Engine.get_main_loop() as SceneTree
		instance = Transicion.new()
		tree.root.add_child.call_deferred(instance)
	return instance


# ---------------------------------------------------------------- construcción
func _ready() -> void:
	layer = 120                                  # por encima de todo
	process_mode = Node.PROCESS_MODE_ALWAYS      # funciona con el juego en pausa

	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])

	overlay = ColorRect.new()
	overlay.color = Color.BLACK
	overlay.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	overlay.modulate.a = 0.0
	add_child(overlay)

	content = Control.new()
	content.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	content.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.modulate.a = 0.0
	content.visible = false   # oculto del todo hasta que haya algo que leer
	add_child(content)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	center.mouse_filter = Control.MOUSE_FILTER_IGNORE
	content.add_child(center)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 16)
	box.mouse_filter = Control.MOUSE_FILTER_IGNORE
	center.add_child(box)

	title_label = Label.new()
	title_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title_label.add_theme_font_override("font", font)
	title_label.add_theme_font_size_override("font_size", 52)
	title_label.add_theme_color_override("font_color", GREEN)
	title_label.add_theme_color_override("font_outline_color", Color(0, 0.12, 0.04, 1))
	title_label.add_theme_constant_override("outline_size", 8)
	box.add_child(title_label)

	var line := ColorRect.new()
	line.color = Color(GREEN, 0.7)
	line.custom_minimum_size = Vector2(320, 3)
	line.size_flags_horizontal = Control.SIZE_SHRINK_CENTER
	line.mouse_filter = Control.MOUSE_FILTER_IGNORE
	box.add_child(line)

	body_label = Label.new()
	body_label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	body_label.custom_minimum_size = Vector2(960, 0)
	body_label.add_theme_font_override("font", font)
	body_label.add_theme_font_size_override("font_size", 20)
	body_label.add_theme_constant_override("line_spacing", 4)
	body_label.add_theme_color_override("font_color", Color("d8f5e0"))
	box.add_child(body_label)

	hint_label = Label.new()
	hint_label.text = "[ presiona cualquier tecla para continuar ]"
	hint_label.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	hint_label.offset_top = -50
	hint_label.offset_bottom = -20
	hint_label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint_label.add_theme_font_override("font", font)
	hint_label.add_theme_font_size_override("font_size", 16)
	hint_label.add_theme_color_override("font_color", GREEN)
	hint_label.modulate.a = 0.0
	content.add_child(hint_label)


# ---------------------------------------------------------------- secuencia
func _run(ruta: String, titulo: String, texto: String) -> void:
	if busy:
		return
	if not ResourceLoader.exists(ruta):
		push_error("Transicion: no existe la escena '%s'. Revisa 'Siguiente Nivel' en el Inspector del portal." % ruta)
		return
	busy = true

	# 1. Pantalla en negro
	overlay.mouse_filter = Control.MOUSE_FILTER_STOP
	await _fade(overlay, 1.0, 0.7)

	# 2. Cambia de nivel (queda oculto detrás del negro)
	get_tree().paused = false
	get_tree().change_scene_to_file(ruta)
	await get_tree().process_frame
	await get_tree().process_frame

	# 3. Relato del nivel, con el juego en pausa para que nada ataque mientras se lee
	if titulo != "" or texto != "":
		get_tree().paused = true
		await _read(titulo, texto)
		get_tree().paused = false

	# 4. Aclara y empieza el nivel
	await get_tree().create_timer(0.3).timeout
	await _fade(overlay, 0.0, 0.8)
	overlay.mouse_filter = Control.MOUSE_FILTER_IGNORE
	busy = false


func _read(titulo: String, texto: String) -> void:
	title_label.text = titulo
	body_label.text = texto
	body_label.visible_characters = 0
	hint_label.modulate.a = 0.0
	typing_done = false
	skip_typing = false
	continue_pressed = false

	content.visible = true
	await _fade(content, 1.0, 0.5)
	await get_tree().create_timer(0.3).timeout   # evita saltarlo sin querer al entrar
	reading = true

	# Máquina de escribir (una tecla muestra todo el texto de golpe)
	var total := texto.length()
	var shown := 0.0
	var last_ms := Time.get_ticks_msec()
	while shown < total and not skip_typing:
		await get_tree().process_frame
		var now_ms := Time.get_ticks_msec()
		shown += CHARS_PER_SECOND * float(now_ms - last_ms) / 1000.0
		last_ms = now_ms
		body_label.visible_characters = int(shown)
	body_label.visible_characters = -1
	typing_done = true

	# Aviso parpadeante y espera a que el jugador continúe
	hint_label.modulate.a = 1.0
	hint_tween = create_tween().set_loops()
	hint_tween.tween_property(hint_label, "modulate:a", 0.25, 0.7)
	hint_tween.tween_property(hint_label, "modulate:a", 1.0, 0.7)
	while not continue_pressed:
		await get_tree().process_frame

	reading = false
	if hint_tween:
		hint_tween.kill()
	await _fade(content, 0.0, 0.4)
	content.visible = false


func _fade(target: CanvasItem, to_alpha: float, duration: float) -> void:
	var tw := create_tween()
	tw.tween_property(target, "modulate:a", to_alpha, duration)
	await tw.finished


# ---------------------------------------------------------------- teclas
func _input(event: InputEvent) -> void:
	if not reading:
		return
	var pressed := false
	if event is InputEventKey:
		pressed = event.pressed and not event.echo
	elif event is InputEventMouseButton:
		pressed = event.pressed
	if not pressed:
		return
	get_viewport().set_input_as_handled()   # que el menú de pausa no reciba la tecla
	if not typing_done:
		skip_typing = true
	else:
		continue_pressed = true
