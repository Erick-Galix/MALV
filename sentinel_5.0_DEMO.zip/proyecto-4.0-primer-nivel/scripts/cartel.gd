extends Area2D

signal leido

@export var titulo: String = "Título"
@export_multiline var texto: String = "Texto del cartel"

var jugador_cerca := false
var panel_abierto := false
var ya_leido := false

@onready var aviso: Label = $Label
@onready var anim: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	add_to_group("carteles")
	aviso.visible = false
	body_entered.connect(_on_body_entered)
	body_exited.connect(_on_body_exited)
	anim.sprite_frames.set_animation_loop("idle", true)
	anim.play("idle")


func _on_body_entered(body: Node) -> void:
	if body.is_in_group("player"):
		jugador_cerca = true
		aviso.visible = true


func _on_body_exited(body: Node) -> void:
	if body.is_in_group("player"):
		jugador_cerca = false
		aviso.visible = false
		panel_abierto = false
		get_tree().call_group("panel_cartel", "cerrar")


func _input(event: InputEvent) -> void:
	if jugador_cerca and event.is_action_pressed("interactuar"):
		panel_abierto = not panel_abierto
		if panel_abierto:
			get_tree().call_group("panel_cartel", "mostrar", titulo, texto)
			if not ya_leido:
				ya_leido = true
				leido.emit()
		else:
			get_tree().call_group("panel_cartel", "cerrar")
