extends PanelContainer

@onready var titulo_label: Label = $MarginContainer/VBoxContainer/Titulo
@onready var texto_label: RichTextLabel = $MarginContainer/VBoxContainer/Texto

func _ready() -> void:
	add_to_group("panel_cartel")
	visible = false
	custom_minimum_size = Vector2(0, 160)
	# Lo coloca abajo, ocupando todo el ancho, con 20 px de margen
	set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE, Control.PRESET_MODE_MINSIZE, 20)
	print("Panel listo")

func mostrar(titulo: String, texto: String) -> void:
	titulo_label.text = titulo
	texto_label.text = texto
	visible = true

func cerrar() -> void:
	visible = false
