extends Area2D
## Portal FINAL del juego: muestra la conclusión de la historia y vuelve al menú principal.
## Va en el último portal del nivel 2 (en lugar del script de portal normal).
## Necesita un CollisionShape2D y un AnimatedSprite2D hijos (animaciones: spawn e idle).

## Escena a la que se vuelve al terminar (por defecto, el menú principal)
@export_file("*.tscn") var siguiente_escena := "res://scenes/main_menu.tscn"
@export var titulo_final := "SISTEMA RESTAURADO"
@export_multiline var texto_final := "Con todos los archivos recuperados, el sistema por fin pudo restaurarse.\n\nMalva quedó semi-destruida e inhabilitada: ya no puede corromper la memoria, frenar el procesador ni robar información.\n\nLa computadora volvió a funcionar en armonía. Los programas corren veloces, los archivos están a salvo y todo vuelve a estar en orden.\n\nY SENTINEL, el antivirus que todos habían olvidado, se convirtió en el héroe de la computadora.\n\nFIN"

## true: el portal espera a que se lean todos los carteles del nivel
## (si el nivel no tiene carteles, aparece directamente)
@export var requiere_carteles := true

var activado := false
var aparecido := false
var carteles_pendientes := 0

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitoring = false          # no funciona hasta terminar la animación spawn
	visible = false
	body_entered.connect(_on_body_entered)

	anim.sprite_frames.set_animation_loop("spawn", false)
	anim.sprite_frames.set_animation_loop("idle", true)

	if not requiere_carteles:
		aparecer()
		return

	await get_tree().process_frame     # espera a que todos los carteles existan
	var carteles := get_tree().get_nodes_in_group("carteles")
	carteles_pendientes = carteles.size()
	if carteles_pendientes == 0:
		aparecer()
		return
	for c in carteles:
		c.leido.connect(_on_cartel_leido)


func _on_cartel_leido() -> void:
	carteles_pendientes -= 1
	if carteles_pendientes <= 0:
		aparecer()


## Muestra el portal con su animación de aparición y lo deja listo para usar
func aparecer() -> void:
	if aparecido:
		return
	aparecido = true
	visible = true
	anim.play("spawn")
	await anim.animation_finished
	anim.play("idle")
	monitoring = true


func _on_body_entered(body: Node) -> void:
	if activado or not body.is_in_group("player"):
		return
	if siguiente_escena == "":
		push_error("Falta elegir 'Siguiente Escena' en el Inspector del portal final")
		return
	activado = true
	set_deferred("monitoring", false)
	Transicion.cambiar_nivel(siguiente_escena, titulo_final, texto_final)
