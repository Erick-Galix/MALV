extends Area2D
## Zona de agua (sirve también para pinchos, lava, etc.).
## Si el jugador la toca: pierde una vida y reaparece en el punto seguro más cercano.
## Necesita un CollisionShape2D hijo que cubra toda el agua.

@export var danio := 1   # vidas que quita


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2   # detecta al jugador (capa 2)
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void:
	if not body.is_in_group("player") or not body.has_method("hazard_hit"):
		return
	var destino := _punto_seguro_mas_cercano(body.global_position)
	# Diferido: es seguro llamarlo desde una señal de física
	body.hazard_hit.call_deferred(destino, danio)


## Devuelve el punto seguro más cercano a "desde" (Vector2.INF si no hay ninguno)
func _punto_seguro_mas_cercano(desde: Vector2) -> Vector2:
	var mejor := Vector2.INF
	var mejor_dist := INF
	for punto in get_tree().get_nodes_in_group("puntos_seguros"):
		if punto is Node2D:
			var d := desde.distance_squared_to(punto.global_position)
			if d < mejor_dist:
				mejor_dist = d
				mejor = punto.global_position
	if mejor_dist == INF:
		push_warning("Agua: no hay puntos seguros. Crea un nodo con puntos_seguros.gd y Marker2D dentro. Usaré el último suelo pisado.")
	return mejor
