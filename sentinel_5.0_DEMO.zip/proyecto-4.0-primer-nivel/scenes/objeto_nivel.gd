extends Area2D

## Elige en el Inspector la escena del siguiente nivel
@export_file("*.tscn") var siguiente_nivel: String
@export var titulo_intro := "NIVEL 2"
@export_multiline var texto_intro := "SENTINEL es un antivirus, el último guardián de esta computadora.\n\nHace mucho tiempo todo funcionaba en armonía: los programas corrían veloces, los archivos estaban a salvo y la computadora vivía feliz. Pero entonces llegó Malva, un virus que corrompió la memoria, ralentizó el procesador y robó la información que mantenía todo en orden.\n\nCon los fragmentos de datos que SENTINEL recuperó en este nivel, ahora puede seguir adelante. Más adentro, entre la tarjeta gráfica y la tarjeta madre, se esconde el resto de la información perdida.\n\nSu misión: encontrarla, destruir a Malva y restablecer el sistema, para que la computadora vuelva a estar feliz."

## true: el portal espera a que se lean todos los carteles del nivel
@export var requiere_carteles := true

var recogido := false
var activado := false
var carteles_pendientes := 0

@onready var anim: AnimatedSprite2D = $AnimatedSprite2D


func _ready() -> void:
	collision_layer = 0
	collision_mask = 2
	monitoring = false          # no funciona hasta terminar la animación spawn
	visible = false
	body_entered.connect(_on_body_entered)

	anim.sprite_frames.set_animation_loop("spawn", false)
	anim.sprite_frames.set_animation_loop("idle", true)

	if not requiere_carteles:
		activar()
		return

	await get_tree().process_frame     # espera a que todos los carteles existan
	var carteles := get_tree().get_nodes_in_group("carteles")
	carteles_pendientes = carteles.size()
	if carteles_pendientes == 0:
		activar()                      # nivel sin carteles: aparece directamente
		return
	for c in carteles:
		c.leido.connect(_on_cartel_leido)


func _on_cartel_leido() -> void:
	carteles_pendientes -= 1
	print("Carteles por leer: ", carteles_pendientes)
	if carteles_pendientes <= 0:
		activar()


## Muestra el portal con su animación de aparición y lo deja listo para usar
func activar() -> void:
	if activado:
		return
	activado = true
	visible = true
	anim.play("spawn")
	await anim.animation_finished
	anim.play("idle")
	monitoring = true


func _on_body_entered(body: Node) -> void:
	if recogido or not body.is_in_group("player"):
		return
	if siguiente_nivel == "":
		push_error("Falta elegir 'Siguiente Nivel' en el Inspector del portal")
		return
	recogido = true
	Transicion.cambiar_nivel(siguiente_nivel, titulo_intro, texto_intro)
