extends Node2D
## Contenedor de puntos seguros del nivel.
## Pon este script en un Node2D llamado "PuntosSeguros" y, dentro, un Marker2D
## por cada lugar firme donde el jugador pueda reaparecer tras caer al agua.

func _ready() -> void:
	for hijo in get_children():
		if hijo is Node2D:
			hijo.add_to_group("puntos_seguros")
