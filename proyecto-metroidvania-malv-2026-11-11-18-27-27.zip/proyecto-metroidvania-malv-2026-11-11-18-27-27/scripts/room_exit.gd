extends Area2D
## Zona de salida: al tocarla el jugador, carga otra sala.
## Collision: Layer vacía, Mask 2 (jugador).

@export_file("*.tscn") var target_room := ""
@export var target_spawn := "Start"


func _ready() -> void:
	body_entered.connect(_on_body_entered)


func _on_body_entered(body: Node) -> void:
	if not body.is_in_group("player"):
		return
	var game := get_tree().current_scene
	if game.has_method("change_room"):
		game.change_room.call_deferred(target_room, target_spawn)
	else:
		push_warning("Ejecuta game.tscn (no la sala sola) para probar las salidas.")
