extends HBoxContainer
## Barra de vida con "máscaras" (una por punto de vida).
## Dibuja las máscaras por código, así funciona sin arte.
## Para usar tus propios sprites, ver las variables full_texture / empty_texture.

@export var full_texture: Texture2D    # opcional: máscara llena
@export var empty_texture: Texture2D   # opcional: máscara vacía
@export var icon_size := Vector2(28, 34)

var icons: Array = []


## Icono individual de vida
class MaskIcon extends Control:
	var full := true
	var full_tex: Texture2D
	var empty_tex: Texture2D

	func set_full(value: bool) -> void:
		if value == full:
			return
		full = value
		queue_redraw()
		# Pequeño "golpe" visual al perder vida
		if not full:
			pivot_offset = size / 2.0
			var tw := create_tween()
			tw.tween_property(self, "scale", Vector2(1.3, 1.3), 0.06)
			tw.tween_property(self, "scale", Vector2.ONE, 0.12)

	func _draw() -> void:
		# Si hay texturas, usarlas
		var tex := full_tex if full else empty_tex
		if tex:
			draw_texture_rect(tex, Rect2(Vector2.ZERO, size), false)
			return

		# Máscara dibujada por código: más ancha arriba, más estrecha abajo
		var c := size / 2.0
		var pts := PackedVector2Array()
		for i in 28:
			var t := TAU * i / 28.0
			var width := 0.5 - 0.15 * sin(t)
			pts.append(c + Vector2(cos(t) * width * size.x, sin(t) * 0.5 * size.y))

		if full:
			draw_colored_polygon(pts, Color("f2f2f2"))
			# Ojos
			var ey := c.y - size.y * 0.08
			var ex := size.x * 0.2
			var eye_l := PackedVector2Array([
				Vector2(c.x - ex - 5, ey - 2), Vector2(c.x - ex + 5, ey + 3),
				Vector2(c.x - ex + 2, ey + 9), Vector2(c.x - ex - 6, ey + 4)])
			var eye_r := PackedVector2Array([
				Vector2(c.x + ex + 5, ey - 2), Vector2(c.x + ex - 5, ey + 3),
				Vector2(c.x + ex - 2, ey + 9), Vector2(c.x + ex + 6, ey + 4)])
			draw_colored_polygon(eye_l, Color("101018"))
			draw_colored_polygon(eye_r, Color("101018"))
		else:
			draw_colored_polygon(pts, Color(1, 1, 1, 0.08))
			var outline := pts.duplicate()
			outline.append(pts[0])
			draw_polyline(outline, Color(1, 1, 1, 0.35), 2.0)


func _ready() -> void:
	# Busca sola al jugador (grupo "player"), así no hace falta ningún script extra
	await get_tree().process_frame
	var p := get_tree().get_first_node_in_group("player")
	if p and icons.is_empty():
		setup(p)


func setup(player: Node) -> void:
	for child in get_children():
		child.queue_free()
	icons.clear()

	for i in player.max_health:
		var icon := MaskIcon.new()
		icon.custom_minimum_size = icon_size
		icon.full_tex = full_texture
		icon.empty_tex = empty_texture
		add_child(icon)
		icons.append(icon)

	_update(player.health)
	if not player.health_changed.is_connected(_update):
		player.health_changed.connect(_update)


func _update(hp: int) -> void:
	for i in icons.size():
		icons[i].set_full(i < hp)
