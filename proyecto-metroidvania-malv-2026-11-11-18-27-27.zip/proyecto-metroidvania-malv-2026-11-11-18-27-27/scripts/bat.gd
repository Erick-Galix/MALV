extends Enemy
## Murciélago: flota cerca de su punto inicial; si ve al jugador lo persigue
## y se lanza en picada contra él. No usa gravedad.
## En el Inspector del nodo raíz: Hit Anim = hurt (el murciélago no tiene "hit").
## Animaciones usadas: idlefly, run, attack, hurt, die.

@export var detect_range := 200.0     # a qué distancia ve al jugador
@export var chase_speed := 90.0
@export var lunge_speed := 280.0      # velocidad de la picada
@export var attack_range := 80.0      # distancia a la que se lanza
@export var sync_to_animation := true # la picada dura lo mismo que tu animación
@export var lunge_time := 0.4         # duración si no hay animación o sync está apagado
@export var recover_time := 0.6       # tiempo que se aleja tras atacar
@export var attack_cooldown := 1.2    # pausa entre picadas
@export var hover_amplitude := 6.0    # cuánto sube y baja al flotar
@export var hover_speed := 2.0
@export var idle_anim := "idlefly"
@export var chase_anim := "run"
@export var attack_anim := "attack"

enum State { HOVER, CHASE, LUNGE, RECOVER }
var state := State.HOVER
var home := Vector2.ZERO
var time := 0.0
var timer := 0.0
var cooldown_timer := 0.0
var lunge_dir := Vector2.RIGHT
var player: Node2D


func _ready() -> void:
	super._ready()
	home = global_position
	if _real(attack_anim) != "":
		sprite.sprite_frames.set_animation_loop(_real(attack_anim), false)


func _physics_process(delta: float) -> void:
	time += delta
	cooldown_timer -= delta
	hurt_timer -= delta

	player = get_tree().get_first_node_in_group("player") as Node2D
	var to_player := Vector2.ZERO
	var dist := INF
	if player:
		to_player = player.global_position - global_position
		dist = to_player.length()
	elif state != State.HOVER:
		state = State.HOVER

	# Aturdido por un golpe: se frena un instante (si estaba atacando, se cancela)
	if hurt_timer > 0.0:
		if state == State.LUNGE:
			state = State.RECOVER
			timer = recover_time
			cooldown_timer = attack_cooldown
		velocity = velocity.move_toward(Vector2.ZERO, 900.0 * delta)
		move_and_slide()
		return

	match state:
		State.HOVER:
			# Flota suavemente alrededor de su punto inicial
			var target := home + Vector2(0.0, sin(time * hover_speed) * hover_amplitude)
			velocity = ((target - global_position) * 4.0).limit_length(speed)
			if absf(velocity.x) > 5.0:
				_face(velocity.x)
			_set_anim(idle_anim)
			if dist < detect_range:
				_dbg("ve al jugador: persigue")
				state = State.CHASE

		State.CHASE:
			velocity = to_player.normalized() * chase_speed
			_face(to_player.x)
			_set_anim(chase_anim)
			if dist > detect_range * 1.6:
				_dbg("pierde al jugador: vuelve a flotar")
				state = State.HOVER
			elif dist < attack_range and cooldown_timer <= 0.0:
				_start_lunge(to_player, dist)

		State.LUNGE:
			# Mira hacia donde se lanza y no cambia de animación hasta terminarla
			velocity = lunge_dir * lunge_speed
			timer -= delta
			if timer <= 0.0:
				state = State.RECOVER
				timer = recover_time
				cooldown_timer = attack_cooldown

		State.RECOVER:
			# Se aleja y sube un poco antes de volver a perseguir
			velocity = Vector2(-lunge_dir.x * 0.5, -1.0).normalized() * chase_speed
			_set_anim(chase_anim)
			timer -= delta
			if timer <= 0.0:
				state = State.CHASE

	move_and_slide()


func _start_lunge(to_player: Vector2, dist: float) -> void:
	state = State.LUNGE
	lunge_dir = to_player.normalized()
	_face(lunge_dir.x)
	timer = _anim_length(attack_anim, lunge_time) if sync_to_animation else lunge_time
	var ok := _play(attack_anim)
	_dbg("picada (dist=%.0f, anim ok=%s, dura %.2fs, mira %d)" % [dist, ok, timer, direction])
