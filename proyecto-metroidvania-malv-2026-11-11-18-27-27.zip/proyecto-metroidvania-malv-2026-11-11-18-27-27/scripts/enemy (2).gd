class_name Enemy
extends CharacterBody2D
## Enemigo base: patrulla, da la vuelta en paredes y bordes, daña por contacto.
## Estructura de la escena:
##   Enemy (CharacterBody2D)  <- este script
##   ├─ Sprite2D
##   ├─ CollisionShape2D
##   └─ ContactArea (Area2D)
##        └─ CollisionShape2D  (un poco más grande que el cuerpo)

@export var speed := 50.0
@export var max_health := 3
@export var contact_damage := 1
@export var gravity := 1100.0
@export var ledge_check_x := 12.0   # distancia delante del enemigo donde busca suelo

var health := 0
var direction := -1
var ledge_check: RayCast2D
var sprite: Node  # AnimatedSprite2D o Sprite2D, lo que tengas
var dead := false
var base_scale := Vector2.ONE   # escala que le pongas al sprite en el editor

# Nombres de las animaciones en tu SpriteFrames (cámbialos en el Inspector)
@export var walk_anim := "walk"
@export var hit_anim := "hit"
@export var die_anim := "die"
@export var sprite_faces_right := false  # pon true si tus dibujos miran a la derecha
@export var debug_ai := false            # imprime en "Salida" lo que decide el enemigo
var anim_names := {}   # nombre normalizado -> nombre real en tu SpriteFrames
var hurt_timer := 0.0  # mientras es > 0 el enemigo está aturdido por un golpe
const HURT_TIME := 0.25


func _ready() -> void:
	health = max_health
	add_to_group("enemies")

	# Capas de colisión (se fijan aquí para evitar errores de configuración)
	collision_layer = 4              # el enemigo vive en la capa 3
	collision_mask = 1               # pisa el mundo (capa 1)
	$ContactArea.collision_layer = 0
	$ContactArea.collision_mask = 2  # solo detecta al jugador (capa 2)

	# Busca el sprite (animado o estático)
	sprite = get_node_or_null("AnimatedSprite2D")
	if sprite == null:
		sprite = get_node_or_null("Sprite2D")
	if sprite is Node2D:
		base_scale = sprite.scale
	_setup_animations()

	# Detector de bordes: un rayo hacia abajo, delante del enemigo
	ledge_check = RayCast2D.new()
	ledge_check.target_position = Vector2(0, 20)
	ledge_check.collision_mask = 1  # solo el mundo (TileMap)
	add_child(ledge_check)
	_update_ledge_check()

	$ContactArea.body_entered.connect(_on_contact)


func _physics_process(delta: float) -> void:
	if not is_on_floor():
		velocity.y += gravity * delta
	_patrol_step()
	move_and_slide()


## Patrulla: da la vuelta en paredes y bordes. Los enemigos hijos la reutilizan.
func _patrol_step() -> void:
	if is_on_floor() and (is_on_wall() or not ledge_check.is_colliding()):
		_flip()
	velocity.x = direction * speed


func _flip() -> void:
	direction *= -1
	_update_ledge_check()
	_apply_flip()


func _apply_flip() -> void:
	if sprite == null:
		return
	# Con dirección -1 (izquierda) y dibujo que mira a la derecha, hay que voltear
	sprite.flip_h = (direction < 0) if sprite_faces_right else (direction > 0)


## Gira para mirar hacia el lado de dx (negativo = izquierda, positivo = derecha)
func _face(dx: float) -> void:
	var d := int(sign(dx))
	if d == 0 or d == direction:
		return
	direction = d
	_update_ledge_check()
	_apply_flip()


## Pone una animación SOLO si no es la que ya está sonando (se puede llamar cada frame)
func _set_anim(anim_name: String) -> void:
	var real_name := _real(anim_name)
	if not (sprite is AnimatedSprite2D) or real_name == "":
		return
	if sprite.animation != real_name or not sprite.is_playing():
		sprite.play(real_name)


func _update_ledge_check() -> void:
	ledge_check.position = Vector2(direction * ledge_check_x, 0)
	ledge_check.force_raycast_update()


func _on_contact(body: Node) -> void:
	if body == self or body.is_in_group("enemies"):
		return
	if body.is_in_group("player") and body.has_method("take_damage"):
		body.take_damage(contact_damage, global_position)


## Lo llama el ataque del jugador
func take_damage(amount: int, _from_position: Vector2 = Vector2.ZERO) -> void:
	if dead:
		return
	health -= amount
	if health <= 0:
		_die()
		return
	hurt_timer = HURT_TIME
	modulate = Color.RED
	_play(hit_anim)
	await get_tree().create_timer(0.2).timeout
	modulate = Color.WHITE
	if not dead:
		_play_move_animation()


func _die() -> void:
	dead = true
	velocity = Vector2.ZERO
	set_physics_process(false)
	$ContactArea.set_deferred("monitoring", false)  # ya no daña
	modulate = Color.WHITE
	if _play(die_anim):
		await sprite.animation_finished
	elif sprite:
		# Sin animación "die": se aplasta y se desvanece
		var tw := create_tween().set_parallel(true)
		tw.tween_property(sprite, "scale", base_scale * Vector2(1.4, 0.1), 0.25)
		tw.tween_property(sprite, "modulate:a", 0.0, 0.25)
		await tw.finished
	queue_free()


## Prepara las animaciones: acepta nombres con espacios ("die 2") o con
## guion bajo ("die_2") y define cuáles se repiten.
func _setup_animations() -> void:
	if not (sprite is AnimatedSprite2D) or sprite.sprite_frames == null:
		_apply_flip()
		return
	for n in sprite.sprite_frames.get_animation_names():
		var real_name := String(n)
		anim_names[real_name.to_lower().replace(" ", "_")] = real_name

	# hit y die se reproducen una sola vez; walk se repite
	for key in [hit_anim, die_anim]:
		if _real(key) != "":
			sprite.sprite_frames.set_animation_loop(_real(key), false)
	if _real(walk_anim) != "":
		sprite.sprite_frames.set_animation_loop(_real(walk_anim), true)

	_apply_flip()
	_play_move_animation()


func _real(anim_name: String) -> String:
	return String(anim_names.get(anim_name.to_lower().replace(" ", "_"), ""))


## Reproduce una animación si existe. Devuelve true si la pudo reproducir.
func _play(anim_name: String) -> bool:
	var real_name := _real(anim_name)
	if sprite is AnimatedSprite2D and real_name != "":
		sprite.stop()
		sprite.play(real_name)
		sprite.frame = 0
		sprite.frame_progress = 0.0
		return true
	return false


## Cuánto dura una animación en segundos (según sus cuadros y FPS)
func _anim_length(anim_name: String, fallback: float) -> float:
	var real_name := _real(anim_name)
	if not (sprite is AnimatedSprite2D) or real_name == "":
		return fallback
	var frames: SpriteFrames = sprite.sprite_frames
	var fps := frames.get_animation_speed(real_name)
	if fps <= 0.0:
		return fallback
	var total := 0.0
	for i in frames.get_frame_count(real_name):
		total += frames.get_frame_duration(real_name, i)
	return total / fps / maxf(sprite.speed_scale, 0.01)


## Mensajes de depuración en la pestaña Salida (actívalos con Debug Ai)
func _dbg(msg: String) -> void:
	if debug_ai:
		print("[", name, "] ", msg)


## Reproduce "walk"; si no existe, usa la primera animación que encuentre
func _play_move_animation() -> void:
	if not (sprite is AnimatedSprite2D):
		return
	if _play(walk_anim):
		return
	var names: PackedStringArray = sprite.sprite_frames.get_animation_names()
	if names.size() > 0:
		sprite.play(names[0])
