extends Enemy
## Hongo: patrulla; si ve al jugador a su altura lo persigue y lo ataca de cerca.
## En el Inspector del nodo raíz: Walk Anim = run (el hongo no tiene "walk").
## Animaciones usadas: run, idle, attack, hit, die.

@export var detect_range := 160.0     # distancia horizontal a la que ve al jugador
@export var chase_speed := 90.0
@export var attack_range := 40.0      # distancia horizontal a la que ataca
@export var attack_damage := 1
@export var sync_to_animation := true # el ataque dura lo mismo que tu animación
@export var attack_time := 0.7        # duración si no hay animación o sync está apagado
@export_range(0.0, 1.0) var hit_moment := 0.5  # en qué punto del ataque conecta (0 = inicio, 1 = final)
@export var attack_cooldown := 1.0    # pausa entre ataques
@export var idle_anim := "idle"
@export var chase_anim := "run"
@export var attack_anim := "attack"

enum State { PATROL, CHASE, ATTACK }
var state := State.PATROL
var state_timer := 0.0
var attack_length := 0.7
var cooldown_timer := 0.0
var hit_done := false
var player: Node2D


func _ready() -> void:
	super._ready()
	# El ataque se reproduce una sola vez
	if _real(attack_anim) != "":
		sprite.sprite_frames.set_animation_loop(_real(attack_anim), false)


func _physics_process(delta: float) -> void:
	cooldown_timer -= delta
	hurt_timer -= delta
	if not is_on_floor():
		velocity.y += gravity * delta

	player = get_tree().get_first_node_in_group("player") as Node2D
	var to_player := Vector2.ZERO
	var dx := INF
	if player:
		to_player = player.global_position - global_position
		dx = absf(to_player.x)
	var same_level := absf(to_player.y) < 60.0

	# Aturdido por un golpe: se frena un instante (si está atacando, el golpe se cancela)
	if hurt_timer > 0.0:
		if state == State.ATTACK:
			state = State.CHASE
			cooldown_timer = attack_cooldown
		velocity.x = move_toward(velocity.x, 0.0, 800.0 * delta)
		move_and_slide()
		return

	match state:
		State.PATROL:
			_patrol_step()
			_set_anim(walk_anim)
			if same_level and dx < detect_range:
				_dbg("ve al jugador: persigue")
				state = State.CHASE

		State.CHASE:
			_face(to_player.x)
			if dx > detect_range * 1.5 or not same_level:
				_dbg("pierde al jugador: patrulla")
				state = State.PATROL
			elif dx < attack_range and cooldown_timer <= 0.0:
				_start_attack(dx)
			elif dx < attack_range:
				velocity.x = 0.0
				_set_anim(idle_anim)   # espera a que acabe el enfriamiento
			else:
				_chase_step()

		State.ATTACK:
			# Quieto y sin girar durante todo el ataque
			velocity.x = 0.0
			state_timer -= delta
			# El golpe conecta en el momento elegido, si el jugador sigue cerca
			if not hit_done and state_timer <= attack_length * (1.0 - hit_moment):
				hit_done = true
				if player and dx < attack_range * 1.5 and same_level \
						and player.has_method("take_damage"):
					player.take_damage(attack_damage, global_position)
					_dbg("golpe conecta")
			if state_timer <= 0.0:
				state = State.CHASE
				cooldown_timer = attack_cooldown

	move_and_slide()


func _chase_step() -> void:
	# No se lanza al vacío ni se estrella contra paredes
	if is_on_floor() and (is_on_wall() or not ledge_check.is_colliding()):
		velocity.x = 0.0
		_set_anim(idle_anim)
	else:
		velocity.x = direction * chase_speed
		_set_anim(chase_anim)


func _start_attack(dx: float) -> void:
	state = State.ATTACK
	attack_length = _anim_length(attack_anim, attack_time) if sync_to_animation else attack_time
	state_timer = attack_length
	hit_done = false
	velocity.x = 0.0
	var ok := _play(attack_anim)
	_dbg("ataca (dx=%.0f, anim ok=%s, dura %.2fs, mira %d)" % [dx, ok, attack_length, direction])
