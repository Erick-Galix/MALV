extends Node
## Escena principal del juego. Contiene al Player (que persiste entre salas)
## y carga/descarga las salas como hijos.
## Estructura de game.tscn:
##   Game (Node)  <- este script
##   └─ Player (instancia de tu escena del jugador)
##        └─ Camera2D (con Position Smoothing activado)

@export_file("*.tscn") var start_room := "res://room1.tscn"
@export var start_spawn := "Start"

@onready var player: Node2D = $Player
@onready var camera: Camera2D = $Player/Camera2D

var current_room: Node2D
var changing := false


func _ready() -> void:
	change_room(start_room, start_spawn)


## Cambia de sala y coloca al jugador en el punto de aparición indicado.
## Llamar con call_deferred desde señales de física.
func change_room(path: String, spawn_name: String) -> void:
	if changing:
		return
	changing = true

	if current_room:
		current_room.queue_free()

	var room: Node2D = load(path).instantiate()
	add_child(room)
	move_child(room, 0)  # la sala queda detrás del jugador
	current_room = room

	player.global_position = room.get_spawn_position(spawn_name)
	if "velocity" in player:
		player.velocity = Vector2.ZERO
	_apply_camera_limits(room)
	camera.reset_smoothing()

	# Pequeño margen para que el jugador no reactive la salida al aparecer
	await get_tree().create_timer(0.2).timeout
	changing = false


func _apply_camera_limits(room: Node2D) -> void:
	var b: Rect2 = room.get_bounds()
	if b.size == Vector2.ZERO:
		# Sala sin TileMapLayer: cámara sin límites
		camera.limit_left = -10000000
		camera.limit_top = -10000000
		camera.limit_right = 10000000
		camera.limit_bottom = 10000000
		return
	camera.limit_left = int(b.position.x)
	camera.limit_top = int(b.position.y)
	camera.limit_right = int(b.end.x)
	camera.limit_bottom = int(b.end.y)
