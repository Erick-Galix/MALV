extends Node2D
class_name Room
## Script raíz de cada sala.
## Estructura de una sala:
##   Room1 (Node2D)  <- este script
##   ├─ TileMapLayer          (el nivel)
##   ├─ Spawns (Node2D)
##   │    ├─ Start (Marker2D)  <- puntos de aparición, el nombre importa
##   │    └─ FromRight (Marker2D)
##   └─ Exits (Node2D)
##        └─ ExitRight (Area2D con room_exit.gd)

@onready var tilemap: TileMapLayer = get_node_or_null("TileMapLayer")


func get_spawn_position(spawn_name: String) -> Vector2:
	var marker := get_node_or_null("Spawns/" + spawn_name)
	if marker:
		return marker.global_position
	push_warning("Spawn '%s' no existe en %s" % [spawn_name, name])
	return global_position


## Rectángulo que ocupa el nivel, para limitar la cámara
func get_bounds() -> Rect2:
	if tilemap == null:
		return Rect2()
	var used := tilemap.get_used_rect()
	var tile_size := Vector2(tilemap.tile_set.tile_size)
	return Rect2(
		tilemap.global_position + Vector2(used.position) * tile_size,
		Vector2(used.size) * tile_size
	)
