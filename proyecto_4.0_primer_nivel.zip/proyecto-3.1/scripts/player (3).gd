extends CharacterBody2D
## Jugador base para metroidvania (Godot 4.x)
## Adjunta este script a un CharacterBody2D con CollisionShape2D y Sprite2D.
## Acciones del Input Map necesarias: move_left, move_right, jump, dash

# --- Habilidades desbloqueables (el núcleo del metroidvania) ---
var can_double_jump := false
var can_dash := false

# --- Ajustes de movimiento ---
@export var speed := 220.0
@export var jump_velocity := -380.0
@export var gravity := 900.0
@export var max_fall_speed := 700.0
@export var dash_speed := 500.0
@export var dash_time := 0.18

# --- "Game feel" ---
const COYOTE_TIME := 0.10       # puedes saltar un instante después de salir del borde
const JUMP_BUFFER := 0.12       # recuerda el salto pulsado justo antes de aterrizar

var coyote_timer := 0.0
var jump_buffer_timer := 0.0
var jumps_left := 1
var dash_timer := 0.0
var dash_available := true
var facing := 1

# --- Vida y daño ---
signal health_changed(new_health: int)
signal died
@export var max_health := 5
var health := 5
var invulnerable_timer := 0.0
var knockback_timer := 0.0

# --- Ataque ---
@export var attack_damage := 1
@export var attack_duration := 0.15
@export var attack_cooldown := 0.3
var attack_timer := 0.0
var attack_cooldown_timer := 0.0
var enemies_hit: Array = []
@onready var attack_area: Area2D = $AttackArea
@export var debug_attack := true   # imprime en "Salida" qué detecta el ataque
var attack_dir := Vector2.RIGHT
var attack_reach := 24.0     # a qué distancia del jugador aparece el golpe
var attack_base_y := 0.0
var slash: ColorRect   # destello visual del golpe (se crea por código)

# --- Animaciones (opcional: nodo AnimatedSprite2D) ---
@onready var anim: AnimatedSprite2D = get_node_or_null("AnimatedSprite2D")
@export var move_anim := "run"            # "run" o "walk": la que se usa al moverte
@export var sprite_faces_right := true    # pon false si tus dibujos miran a la izquierda
@export var combo_window := 0.5           # tiempo para encadenar el 2.º golpe
@export var finisher_damage_mult := 2     # multiplicador de daño del golpe final
var anim_names := {}       # "fall_loop" -> nombre real en tu SpriteFrames
var attack_anim := ""      # animación de ataque en curso (no se interrumpe)
var combo_step := 0
var combo_timer := 0.0
var current_attack_damage := 1


func _ready() -> void:
	add_to_group("player")
	health = max_health
	attack_area.monitoring = false

	# Capas de colisión (se fijan aquí para evitar errores de configuración)
	collision_layer = 2              # el jugador vive en la capa 2
	collision_mask = 1               # pisa el mundo (capa 1)
	attack_area.collision_layer = 0
	attack_area.collision_mask = 4   # el golpe solo detecta enemigos (capa 3)

	# El alcance sale de donde pusiste el AttackArea en la escena
	if abs(attack_area.position.x) > 1.0:
		attack_reach = abs(attack_area.position.x)
	attack_base_y = attack_area.position.y

	# Destello visual del golpe: copia el tamaño de la forma del AttackArea
	var slash_size := Vector2(24, 20)
	for c in attack_area.get_children():
		if c is CollisionShape2D and c.shape is RectangleShape2D:
			slash_size = c.shape.size
	slash = ColorRect.new()
	slash.color = Color(1, 1, 1, 0.55)
	slash.size = slash_size
	slash.position = -slash_size / 2.0
	slash.mouse_filter = Control.MOUSE_FILTER_IGNORE
	slash.visible = false
	attack_area.add_child(slash)

	# Avisa si falta alguna acción en Proyecto > Configuración > Mapa de entradas
	for action in ["move_left", "move_right", "jump", "dash", "attack", "move_up", "move_down"]:
		if not InputMap.has_action(action):
			push_error("FALTA la acción '%s' en el Mapa de entradas" % action)

	_setup_animations()


func _physics_process(delta: float) -> void:
	invulnerable_timer -= delta
	knockback_timer -= delta
	modulate.a = 0.5 if invulnerable_timer > 0.0 else 1.0

	var dir := Input.get_axis("move_left", "move_right")
	if dir != 0:
		facing = sign(dir)

	# Dash: durante el dash no hay gravedad ni control
	if dash_timer > 0.0:
		dash_timer -= delta
		velocity = Vector2(facing * dash_speed, 0)
		move_and_slide()
		_update_animation()
		return

	# Gravedad
	if not is_on_floor():
		velocity.y = min(velocity.y + gravity * delta, max_fall_speed)
		coyote_timer -= delta
	else:
		coyote_timer = COYOTE_TIME
		jumps_left = 2 if can_double_jump else 1
		dash_available = true

	# Salto con buffer + coyote time
	if Input.is_action_just_pressed("jump"):
		jump_buffer_timer = JUMP_BUFFER
	jump_buffer_timer -= delta

	if jump_buffer_timer > 0.0:
		if coyote_timer > 0.0:
			_jump()
			coyote_timer = 0.0
		elif jumps_left > 0 and can_double_jump and not is_on_floor():
			_jump()

	# Salto variable: soltar el botón corta el salto
	if Input.is_action_just_released("jump") and velocity.y < 0:
		velocity.y *= 0.5

	# Dash
	if can_dash and dash_available and Input.is_action_just_pressed("dash"):
		dash_timer = dash_time
		dash_available = false

	# Movimiento horizontal
	_handle_attack(delta)

	if knockback_timer <= 0.0:
		velocity.x = dir * speed
	move_and_slide()
	_update_animation()


## Prepara las animaciones: acepta nombres con espacios ("fall loop") o con
## guion bajo ("fall_loop") y define cuáles se repiten.
func _setup_animations() -> void:
	if anim == null or anim.sprite_frames == null:
		return
	for n in anim.sprite_frames.get_animation_names():
		var real_name := String(n)
		anim_names[real_name.to_lower().replace(" ", "_")] = real_name

	for n in ["idle", "run", "walk", "fall_loop"]:   # se repiten
		if _has_anim(n):
			anim.sprite_frames.set_animation_loop(_real(n), true)
	for n in ["jump", "fall", "combo", "combo_end"]: # se reproducen una vez
		if _has_anim(n):
			anim.sprite_frames.set_animation_loop(_real(n), false)

	_play_anim("idle")


func _has_anim(n: String) -> bool:
	return anim_names.has(n)


func _real(n: String) -> String:
	return String(anim_names.get(n, ""))


func _play_anim(n: String, restart := false) -> void:
	if anim == null or not _has_anim(n):
		return
	var real_name := _real(n)
	if anim.animation != real_name or restart:
		anim.stop()
		anim.play(real_name)


func _update_animation() -> void:
	if anim == null:
		return
	# Voltear según hacia dónde mira
	anim.flip_h = (facing < 0) if sprite_faces_right else (facing > 0)

	# Mientras suena una animación de combo no se interrumpe
	if attack_anim != "":
		if anim.animation == attack_anim and anim.is_playing():
			return
		attack_anim = ""

	var anim_name := "idle"
	if dash_timer > 0.0:
		anim_name = "dash"
	elif not is_on_floor():
		if velocity.y < 0.0:
			anim_name = "jump"
		elif anim.animation == _real("fall_loop"):
			anim_name = "fall_loop"
		elif anim.animation == _real("fall") and not anim.is_playing():
			anim_name = "fall_loop"   # "fall" terminó: pasa a "fall_loop"
		else:
			anim_name = "fall" if _has_anim("fall") else "fall_loop"
	elif abs(velocity.x) > 10.0:
		anim_name = move_anim

	_play_anim(anim_name)


func _handle_attack(delta: float) -> void:
	attack_cooldown_timer -= delta
	combo_timer -= delta
	if combo_timer <= 0.0:
		combo_step = 0

	# Iniciar ataque
	if Input.is_action_just_pressed("attack") and attack_cooldown_timer <= 0.0:
		attack_timer = attack_duration
		attack_cooldown_timer = attack_cooldown
		enemies_hit.clear()
		attack_dir = _get_attack_dir()
		attack_area.position = Vector2(0, attack_base_y) + attack_dir * attack_reach
		attack_area.rotation = attack_dir.angle()
		attack_area.monitoring = true
		slash.visible = true

		# Combo: 1.er golpe "combo"; si encadenas otro a tiempo, "combo_end" (más daño)
		var key := "combo"
		current_attack_damage = attack_damage
		if combo_step == 1 and combo_timer > 0.0:
			key = "combo_end"
			current_attack_damage = attack_damage * finisher_damage_mult
			combo_step = 0
		else:
			combo_step = 1
		combo_timer = combo_window + attack_cooldown
		attack_anim = _real(key)   # queda vacío si esa animación no existe
		_play_anim(key, true)

		if debug_attack:
			print("[ATAQUE] pulsado. AttackArea mask=", attack_area.collision_mask)

	# Durante el ataque: dañar a cada enemigo una sola vez
	if attack_timer > 0.0:
		attack_timer -= delta
		for body in attack_area.get_overlapping_bodies():
			if debug_attack:
				print("[ATAQUE] detecta: ", body.name, " | en grupo enemies: ", body.is_in_group("enemies"))
			if body.is_in_group("enemies") and body not in enemies_hit:
				enemies_hit.append(body)
				body.take_damage(current_attack_damage)
				# Golpe hacia abajo en el aire: rebote (pogo)
				if attack_dir == Vector2.DOWN:
					velocity.y = jump_velocity * 0.8
					jumps_left = 2 if can_double_jump else 1
	else:
		attack_area.monitoring = false
		slash.visible = false


## Arriba si mantienes arriba, abajo si mantienes abajo en el aire, si no al frente
func _get_attack_dir() -> Vector2:
	if InputMap.has_action("move_up") and Input.is_action_pressed("move_up"):
		return Vector2.UP
	if InputMap.has_action("move_down") and Input.is_action_pressed("move_down") and not is_on_floor():
		return Vector2.DOWN
	return Vector2(facing, 0)


func take_damage(amount: int, from_position: Vector2 = Vector2.ZERO) -> void:
	if invulnerable_timer > 0.0:
		return
	health -= amount
	health_changed.emit(health)
	invulnerable_timer = 1.0
	# Empujón hacia el lado contrario al enemigo
	var push_dir: float = sign(global_position.x - from_position.x)
	if push_dir == 0:
		push_dir = -facing
	velocity = Vector2(push_dir * 250.0, -200.0)
	knockback_timer = 0.2
	if health <= 0:
		died.emit()
		get_tree().reload_current_scene.call_deferred()  # provisional: reinicia la sala


func _jump() -> void:
	velocity.y = jump_velocity
	jumps_left -= 1
	jump_buffer_timer = 0.0


## Llama a esto desde un pickup/jefe para dar habilidades
func unlock_ability(ability: String) -> void:
	match ability:
		"double_jump": can_double_jump = true
		"dash": can_dash = true
