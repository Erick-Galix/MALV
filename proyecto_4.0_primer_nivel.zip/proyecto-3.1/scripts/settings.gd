class_name Settings
extends RefCounted
## Ajustes del juego (pantalla completa y volumen).
## NO es un autoload: se usa directamente, por ejemplo  Settings.fullscreen
## o  Settings.set_volume(0.5). Se guardan en un archivo del usuario.

const PATH := "user://settings.cfg"

static var fullscreen := false
static var volume := 0.8   # de 0.0 a 1.0
static var _loaded := false


## Carga lo guardado y lo aplica. Se puede llamar muchas veces: solo actúa la primera.
static func load_settings() -> void:
	if _loaded:
		return
	_loaded = true
	var cfg := ConfigFile.new()
	if cfg.load(PATH) == OK:
		fullscreen = cfg.get_value("video", "fullscreen", false)
		volume = cfg.get_value("audio", "volume", 0.8)
	apply()


static func apply() -> void:
	if fullscreen:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_FULLSCREEN)
	else:
		DisplayServer.window_set_mode(DisplayServer.WINDOW_MODE_WINDOWED)
	# El bus 0 es "Master": afecta a todo el sonido
	AudioServer.set_bus_mute(0, volume <= 0.001)
	AudioServer.set_bus_volume_db(0, linear_to_db(maxf(volume, 0.001)))


static func set_fullscreen(value: bool) -> void:
	fullscreen = value
	apply()
	save()


static func set_volume(value: float) -> void:
	volume = clampf(value, 0.0, 1.0)
	apply()


static func save() -> void:
	var cfg := ConfigFile.new()
	cfg.set_value("video", "fullscreen", fullscreen)
	cfg.set_value("audio", "volume", volume)
	cfg.save(PATH)
