extends Control
## Introducción estilo terminal (Godot 4.x)
## Escribe el texto letra por letra. Cualquier tecla o clic:
##   - mientras escribe: muestra todo el texto de golpe
##   - al terminar: pasa a la siguiente escena

@export_file("*.tscn") var next_scene := "res://scenes/game.tscn"
@export var char_delay := 0.03   # segundos entre letras
@export var line_pause := 0.4    # pausa al final de cada línea

const LINES := [
	"> INICIANDO SISTEMA...",
	"> ERROR: 4.382 ARCHIVOS CORRUPTOS",
	"> ERROR: NÚCLEO COMPROMETIDO",
	"> ÚLTIMO PROGRAMA DE DEFENSA DETECTADO",
	"> CARGANDO: SENTINEL.EXE",
	"> PERMISOS: 0%",
	"> ...",
	"> Despierta, Sentinel. Queda poco tiempo.",
]

var label: Label
var prompt: Label
var skipped := false
var finished := false


func _ready() -> void:
	# Fondo negro
	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	# Fuente monoespaciada
	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])

	# Texto principal
	label = Label.new()
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	label.offset_left = 40
	label.offset_top = 40
	label.offset_right = -40
	label.offset_bottom = -80
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_override("font", font)
	label.add_theme_font_size_override("font_size", 22)
	label.add_theme_color_override("font_color", Color("33ff66"))
	add_child(label)

	# Aviso para continuar (oculto hasta terminar)
	prompt = Label.new()
	prompt.text = "[ presiona cualquier tecla ]"
	prompt.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	prompt.offset_top = -60
	prompt.offset_bottom = -20
	prompt.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	prompt.add_theme_font_override("font", font)
	prompt.add_theme_font_size_override("font_size", 18)
	prompt.add_theme_color_override("font_color", Color("33ff66"))
	prompt.visible = false
	add_child(prompt)

	_run()


func _run() -> void:
	for line in LINES:
		for ch in line:
			if skipped:
				_finish()
				return
			label.text += ch
			await get_tree().create_timer(char_delay).timeout
		label.text += "\n"
		await get_tree().create_timer(line_pause).timeout
	_finish()


func _finish() -> void:
	label.text = "\n".join(LINES)
	finished = true
	prompt.visible = true
	# Parpadeo del aviso
	var tween := create_tween().set_loops()
	tween.tween_property(prompt, "modulate:a", 0.2, 0.6)
	tween.tween_property(prompt, "modulate:a", 1.0, 0.6)


func _unhandled_input(event: InputEvent) -> void:
	var pressed: bool = false
	if event is InputEventKey:
		pressed = event.pressed and not event.echo
	elif event is InputEventMouseButton:
		pressed = event.pressed
	if not pressed:
		return
	if finished:
		if ResourceLoader.exists(next_scene):
			Fader.go(get_tree(), next_scene)   # negro y empieza el juego
		else:
			prompt.text = "ERROR: no existe la escena '%s'. Cambia Next Scene en el Inspector." % next_scene
			prompt.modulate.a = 1.0
	else:
		skipped = true
