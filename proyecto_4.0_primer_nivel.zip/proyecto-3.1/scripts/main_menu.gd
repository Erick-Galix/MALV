extends Control
## Menú principal: Jugar, Ajustes y Salir. Se construye por código.
## Escena: un nodo Control vacío con este script.
## Para poner tu imagen de fondo: arrástrala a "Background Image" en el Inspector.

@export var game_title := "SENTINEL"                  # nombre de tu juego
@export var background_image: Texture2D               # tu imagen de fondo (opcional)
@export var slow_zoom := true                         # acerca el fondo lentamente
@export_range(0.0, 1.0) var side_shade := 0.85        # oscuridad a la izquierda (para leer mejor)
@export_file("*.tscn") var story_scene := "res://scenes/story_intro.tscn"

const GREEN := Color("33ff66")

var font: SystemFont
var play_button: Button
var settings_button: Button
var quit_button: Button
var starting := false


func _ready() -> void:
	Settings.load_settings()   # aplica pantalla completa y volumen guardados
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	font = SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])

	_build_background()
	var items := _build_menu()

	# Aparición escalonada: título y luego cada botón
	var tw := create_tween().set_parallel(true)
	for i in items.size():
		items[i].modulate.a = 0.0
		tw.tween_property(items[i], "modulate:a", 1.0, 0.6).set_delay(0.2 + i * 0.12)

	play_button.grab_focus()   # se puede navegar con el teclado


# ---------------------------------------------------------------- fondo
func _build_background() -> void:
	if background_image:
		var bg := TextureRect.new()
		bg.texture = background_image
		bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		bg.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
		bg.stretch_mode = TextureRect.STRETCH_KEEP_ASPECT_COVERED
		bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
		add_child(bg)
		if slow_zoom:
			bg.pivot_offset = get_viewport_rect().size / 2.0
			var zoom := create_tween().set_loops()
			zoom.tween_property(bg, "scale", Vector2(1.06, 1.06), 18.0) \
				.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
			zoom.tween_property(bg, "scale", Vector2.ONE, 18.0) \
				.set_trans(Tween.TRANS_SINE).set_ease(Tween.EASE_IN_OUT)
	else:
		# Sin imagen: fondo oscuro liso
		var flat := ColorRect.new()
		flat.color = Color("05080a")
		flat.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
		add_child(flat)

	# Degradado oscuro de izquierda a derecha, para que el menú se lea bien
	var grad := Gradient.new()
	grad.set_color(0, Color(0, 0, 0, side_shade))
	grad.set_color(1, Color(0, 0, 0, 0.0))
	var grad_tex := GradientTexture2D.new()
	grad_tex.gradient = grad
	grad_tex.fill_from = Vector2(0, 0)
	grad_tex.fill_to = Vector2(1, 0)
	grad_tex.width = 256
	grad_tex.height = 4
	var shade := TextureRect.new()
	shade.texture = grad_tex
	shade.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	shade.expand_mode = TextureRect.EXPAND_IGNORE_SIZE
	shade.stretch_mode = TextureRect.STRETCH_SCALE
	shade.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(shade)


# ---------------------------------------------------------------- menú
func _build_menu() -> Array:
	var margin := MarginContainer.new()
	margin.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	margin.add_theme_constant_override("margin_left", 90)
	margin.add_theme_constant_override("margin_right", 90)
	add_child(margin)

	var box := VBoxContainer.new()
	box.alignment = BoxContainer.ALIGNMENT_CENTER
	box.size_flags_horizontal = Control.SIZE_SHRINK_BEGIN
	box.add_theme_constant_override("separation", 14)
	margin.add_child(box)

	var items: Array = []

	# Título con contorno
	var title := Label.new()
	title.text = game_title
	title.add_theme_font_override("font", font)
	title.add_theme_font_size_override("font_size", 72)
	title.add_theme_color_override("font_color", GREEN)
	title.add_theme_color_override("font_outline_color", Color(0, 0.12, 0.04, 1))
	title.add_theme_constant_override("outline_size", 10)
	box.add_child(title)
	items.append(title)

	# Línea decorativa bajo el título
	var line := ColorRect.new()
	line.color = Color(GREEN, 0.7)
	line.custom_minimum_size = Vector2(300, 3)
	box.add_child(line)
	items.append(line)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 26)
	box.add_child(spacer)

	# Botones
	play_button = _make_button("Jugar")
	settings_button = _make_button("Ajustes")
	quit_button = _make_button("Salir")
	for b in [play_button, settings_button, quit_button]:
		box.add_child(b)
		items.append(b)

	play_button.pressed.connect(_on_play)
	settings_button.pressed.connect(_on_settings)
	quit_button.pressed.connect(_on_quit)
	return items


func _make_button(text: String) -> Button:
	var b := Button.new()
	b.text = text
	b.alignment = HORIZONTAL_ALIGNMENT_LEFT
	b.custom_minimum_size = Vector2(300, 54)
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", 24)
	b.add_theme_color_override("font_color", Color("b8f5cc"))
	b.add_theme_color_override("font_hover_color", Color.WHITE)
	b.add_theme_color_override("font_focus_color", Color.WHITE)
	b.add_theme_color_override("font_pressed_color", GREEN)

	var normal := StyleBoxFlat.new()
	normal.bg_color = Color(0.02, 0.07, 0.04, 0.55)
	normal.border_color = Color(GREEN, 0.3)
	normal.set_border_width_all(2)
	normal.set_corner_radius_all(6)
	normal.content_margin_left = 22
	normal.content_margin_right = 16
	normal.content_margin_top = 10
	normal.content_margin_bottom = 10

	var hover := normal.duplicate() as StyleBoxFlat
	hover.bg_color = Color(GREEN, 0.18)
	hover.border_color = GREEN

	var pressed := hover.duplicate() as StyleBoxFlat
	pressed.bg_color = Color(GREEN, 0.32)

	b.add_theme_stylebox_override("normal", normal)
	b.add_theme_stylebox_override("hover", hover)
	b.add_theme_stylebox_override("focus", hover)
	b.add_theme_stylebox_override("pressed", pressed)
	return b


# ---------------------------------------------------------------- acciones
func _on_play() -> void:
	if starting:
		return
	if not ResourceLoader.exists(story_scene):
		push_error("Menú: no existe la escena '%s'. Cambia Story Scene en el Inspector." % story_scene)
		play_button.text = "Falta la escena (ver Salida)"
		return
	starting = true
	Fader.go(get_tree(), story_scene)   # pantalla en negro y empieza la historia


func _on_settings() -> void:
	var menu := SettingsMenu.new()
	add_child(menu)
	menu.closed.connect(func():
		menu.queue_free()
		settings_button.grab_focus()
	)


func _on_quit() -> void:
	get_tree().quit()
