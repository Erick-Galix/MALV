extends Control
## Introducción de la historia (el virus): frases que aparecen y se desvanecen
## sobre fondo negro. Cualquier tecla o clic salta a la siguiente frase.
## Escena: un nodo Control vacío con este script.

@export_file("*.tscn") var next_scene := "res://scenes/intro.tscn"   # la intro de terminal
@export var fade_time := 1.0   # segundos de aparición y desaparición
@export var hold_time := 2.6   # segundos que se queda cada frase

const LINES := [
	"Hace mucho, alguien construyó un sistema para guardar todo lo que importaba.",
	"Pero un día apareció un error. Un archivo corrupto, pequeño, olvidado.",
	"Creció. Aprendió. Empezó a pensar.",
	"Lo llamaron MALVA.",
	"Y decidió que la única forma de liberar al sistema era borrarlo todo.",
	"Solo queda un programa de defensa. Viejo. Sin actualizar. Casi nadie recuerda que existe.",
	"Su nombre es SENTINEL.",
]

var label: Label
var hint: Label
var skipped := false


func _ready() -> void:
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])

	var bg := ColorRect.new()
	bg.color = Color.BLACK
	bg.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	bg.mouse_filter = Control.MOUSE_FILTER_IGNORE
	add_child(bg)

	label = Label.new()
	label.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	label.offset_left = 120
	label.offset_right = -120
	label.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	label.vertical_alignment = VERTICAL_ALIGNMENT_CENTER
	label.autowrap_mode = TextServer.AUTOWRAP_WORD_SMART
	label.add_theme_font_override("font", font)
	label.add_theme_font_size_override("font_size", 26)
	label.add_theme_color_override("font_color", Color("d8f5e0"))
	label.modulate.a = 0.0
	add_child(label)

	hint = Label.new()
	hint.text = "[ presiona cualquier tecla para avanzar ]"
	hint.set_anchors_and_offsets_preset(Control.PRESET_BOTTOM_WIDE)
	hint.offset_top = -50
	hint.offset_bottom = -20
	hint.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	hint.add_theme_font_override("font", font)
	hint.add_theme_font_size_override("font_size", 14)
	hint.add_theme_color_override("font_color", Color(1, 1, 1, 0.3))
	add_child(hint)

	_play_story()


func _play_story() -> void:
	await get_tree().create_timer(0.5).timeout
	for line in LINES:
		skipped = false
		label.text = line
		await _fade(1.0)
		await _hold()
		await _fade(0.0)
		await get_tree().create_timer(0.3).timeout
	Fader.go(get_tree(), next_scene)   # negro y pasa a la intro de terminal


func _fade(to_alpha: float) -> void:
	# Si el jugador saltó la frase, desaparece más rápido
	var duration := 0.15 if (skipped and to_alpha == 0.0) else fade_time
	var tw := create_tween()
	tw.tween_property(label, "modulate:a", to_alpha, duration)
	await tw.finished


func _hold() -> void:
	var elapsed := 0.0
	while elapsed < hold_time and not skipped:
		await get_tree().process_frame
		elapsed += get_process_delta_time()


func _unhandled_input(event: InputEvent) -> void:
	var pressed := false
	if event is InputEventKey:
		pressed = event.pressed and not event.echo
	elif event is InputEventMouseButton:
		pressed = event.pressed
	if pressed:
		skipped = true
