class_name SettingsMenu
extends Control
## Panel de ajustes (pantalla completa y volumen), construido por código.
## Se reutiliza en el menú principal y en el menú de pausa.

signal closed


func _ready() -> void:
	Settings.load_settings()
	process_mode = Node.PROCESS_MODE_ALWAYS
	set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)

	var font := SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])
	var green := Color("33ff66")

	# Fondo oscuro (también bloquea los clics del menú que está detrás)
	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.8)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	add_child(center)

	var panel := PanelContainer.new()
	panel.custom_minimum_size = Vector2(480, 0)
	center.add_child(panel)

	var margin := MarginContainer.new()
	for side in ["left", "right", "top", "bottom"]:
		margin.add_theme_constant_override("margin_" + side, 28)
	panel.add_child(margin)

	var box := VBoxContainer.new()
	box.add_theme_constant_override("separation", 22)
	margin.add_child(box)

	# Título
	var title := Label.new()
	title.text = "AJUSTES"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_override("font", font)
	title.add_theme_font_size_override("font_size", 30)
	title.add_theme_color_override("font_color", green)
	box.add_child(title)

	# Pantalla completa
	var fs := CheckButton.new()
	fs.text = "Pantalla completa"
	fs.button_pressed = Settings.fullscreen
	fs.add_theme_font_override("font", font)
	fs.add_theme_font_size_override("font_size", 20)
	fs.toggled.connect(Settings.set_fullscreen)
	box.add_child(fs)

	# Volumen
	var row := HBoxContainer.new()
	row.add_theme_constant_override("separation", 14)
	box.add_child(row)

	var vol_label := Label.new()
	vol_label.text = "Volumen"
	vol_label.add_theme_font_override("font", font)
	vol_label.add_theme_font_size_override("font_size", 20)
	row.add_child(vol_label)

	var slider := HSlider.new()
	slider.min_value = 0.0
	slider.max_value = 1.0
	slider.step = 0.01
	slider.value = Settings.volume
	slider.size_flags_horizontal = Control.SIZE_EXPAND_FILL
	slider.size_flags_vertical = Control.SIZE_SHRINK_CENTER
	slider.custom_minimum_size = Vector2(180, 0)
	row.add_child(slider)

	var pct := Label.new()
	pct.text = "%d%%" % roundi(Settings.volume * 100.0)
	pct.custom_minimum_size = Vector2(60, 0)
	pct.add_theme_font_override("font", font)
	pct.add_theme_font_size_override("font_size", 20)
	row.add_child(pct)

	slider.value_changed.connect(Settings.set_volume)
	slider.value_changed.connect(func(v: float): pct.text = "%d%%" % roundi(v * 100.0))
	slider.drag_ended.connect(func(_changed: bool): Settings.save())

	# Volver
	var back := Button.new()
	back.text = "Volver"
	back.custom_minimum_size = Vector2(0, 46)
	back.add_theme_font_override("font", font)
	back.add_theme_font_size_override("font_size", 20)
	back.pressed.connect(_close)
	box.add_child(back)

	fs.grab_focus()


func _close() -> void:
	Settings.save()
	closed.emit()


func _unhandled_input(event: InputEvent) -> void:
	if event.is_action_pressed("ui_cancel"):
		get_viewport().set_input_as_handled()
		_close()
