extends CanvasLayer
## Menú de pausa (tecla Esc). Va como nodo dentro de game.tscn.
## Opciones: Continuar, Ajustes, Menú principal, Salir del juego.

@export_file("*.tscn") var main_menu_scene := "res://scenes/main_menu.tscn"

var root: Control
var box: VBoxContainer
var font: SystemFont
var resume_button: Button
var settings_button: Button
var settings_menu: SettingsMenu = null


func _ready() -> void:
	layer = 50
	process_mode = Node.PROCESS_MODE_ALWAYS   # sigue funcionando con el juego en pausa

	font = SystemFont.new()
	font.font_names = PackedStringArray(["Courier New", "Consolas", "monospace"])

	root = Control.new()
	root.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.visible = false
	add_child(root)

	var dim := ColorRect.new()
	dim.color = Color(0, 0, 0, 0.65)
	dim.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(dim)

	var center := CenterContainer.new()
	center.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	root.add_child(center)

	box = VBoxContainer.new()
	box.add_theme_constant_override("separation", 12)
	center.add_child(box)

	var title := Label.new()
	title.text = "PAUSA"
	title.horizontal_alignment = HORIZONTAL_ALIGNMENT_CENTER
	title.add_theme_font_override("font", font)
	title.add_theme_font_size_override("font_size", 42)
	title.add_theme_color_override("font_color", Color("33ff66"))
	box.add_child(title)

	var spacer := Control.new()
	spacer.custom_minimum_size = Vector2(0, 16)
	box.add_child(spacer)

	resume_button = _add_button("Continuar", _resume)
	settings_button = _add_button("Ajustes", _open_settings)
	_add_button("Menú principal", _to_main_menu)
	_add_button("Salir del juego", _quit)


func _add_button(text: String, callback: Callable) -> Button:
	var b := Button.new()
	b.text = text
	b.custom_minimum_size = Vector2(300, 50)
	b.add_theme_font_override("font", font)
	b.add_theme_font_size_override("font_size", 22)
	b.pressed.connect(callback)
	box.add_child(b)
	return b


func _unhandled_input(event: InputEvent) -> void:
	if Fader.is_busy():
		return
	# Con los ajustes abiertos, Esc los cierra (lo gestiona el propio panel)
	if event.is_action_pressed("ui_cancel") and settings_menu == null:
		get_viewport().set_input_as_handled()
		if root.visible:
			_resume()
		else:
			_pause()


func _pause() -> void:
	root.visible = true
	get_tree().paused = true
	resume_button.grab_focus()


func _resume() -> void:
	root.visible = false
	get_tree().paused = false


func _open_settings() -> void:
	settings_menu = SettingsMenu.new()
	root.add_child(settings_menu)
	settings_menu.closed.connect(_on_settings_closed)


func _on_settings_closed() -> void:
	settings_menu.queue_free()
	settings_menu = null
	settings_button.grab_focus()


func _to_main_menu() -> void:
	root.visible = false
	Fader.go(get_tree(), main_menu_scene)


func _quit() -> void:
	get_tree().quit()
