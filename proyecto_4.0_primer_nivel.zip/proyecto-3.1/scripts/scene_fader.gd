class_name Fader
extends CanvasLayer
## Cambia de escena pasando por negro.
## NO es un autoload: se crea solo la primera vez que se usa.
## Uso desde cualquier script:  Fader.go(get_tree(), "res://scenes/game.tscn")

static var instance: Fader

var rect: ColorRect
var busy := false


static func get_instance(tree: SceneTree) -> Fader:
	if instance == null or not is_instance_valid(instance):
		instance = Fader.new()
		tree.root.add_child(instance)
	return instance


## Atajo para cambiar de escena con fundido a negro
static func go(tree: SceneTree, path: String, black_time := 0.4) -> void:
	get_instance(tree).change_scene(path, black_time)


## ¿Hay una transición en curso?
static func is_busy() -> bool:
	return instance != null and is_instance_valid(instance) and instance.busy


func _ready() -> void:
	layer = 100                                  # por encima de todo
	process_mode = Node.PROCESS_MODE_ALWAYS      # funciona aunque el juego esté en pausa
	rect = ColorRect.new()
	rect.color = Color.BLACK
	rect.set_anchors_and_offsets_preset(Control.PRESET_FULL_RECT)
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE
	rect.modulate.a = 0.0
	add_child(rect)


func fade_out(duration := 0.6) -> void:
	rect.mouse_filter = Control.MOUSE_FILTER_STOP   # bloquea clics mientras oscurece
	var tw := create_tween()
	tw.tween_property(rect, "modulate:a", 1.0, duration)
	await tw.finished


func fade_in(duration := 0.6) -> void:
	var tw := create_tween()
	tw.tween_property(rect, "modulate:a", 0.0, duration)
	await tw.finished
	rect.mouse_filter = Control.MOUSE_FILTER_IGNORE


## Oscurece, cambia de escena, espera un momento en negro y aclara.
func change_scene(path: String, black_time := 0.4) -> void:
	if busy:
		return
	if not ResourceLoader.exists(path):
		push_error("Fader: no existe la escena '%s'. Revisa la ruta en el Inspector." % path)
		return
	busy = true
	await fade_out()
	get_tree().paused = false
	get_tree().change_scene_to_file(path)
	await get_tree().create_timer(black_time).timeout
	await fade_in()
	busy = false
